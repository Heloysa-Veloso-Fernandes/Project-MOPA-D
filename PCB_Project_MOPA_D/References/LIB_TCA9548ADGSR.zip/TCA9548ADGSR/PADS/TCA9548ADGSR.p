*PADS-LIBRARY-PART-TYPES-V9*

TCA9548ADGSR SOP50P490X110-24N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.07.10.47.22
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TCA9548ADGSR
"Mouser Part Number" 595-TCA9548ADGSR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TCA9548ADGSR?qs=olJun0bQHM%252B7USbLxm4jDw%3D%3D
"Arrow Part Number" TCA9548ADGSR
"Arrow Price/Stock" https://www.arrow.com/en/products/tca9548adgsr/texas-instruments.html?utm_currency=USD&region=nac
"Description" Switch ICs - Various 8-channel 1.65- to 5 .5-V I2C/SMBus switc
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tca9548a.pdf?ts=1738746169750&ref_url=https%253A%252F%252Fwww.mouser.de%252F
"Geometry.Height" 1.1mm
GATE 1 24 0
TCA9548ADGSR
1 0 U A0
2 0 U A1
3 0 U \RESET
4 0 U SD0
5 0 U SC0
6 0 U SD1
7 0 U SC1
8 0 U SD2
9 0 U SC2
10 0 U SD3
11 0 U SC3
12 0 U GND
24 0 U VCC
23 0 U SDA
22 0 U SCL
21 0 U A2
20 0 U SC7
19 0 U SD7
18 0 U SC6
17 0 U SD6
16 0 U SC5
15 0 U SD5
14 0 U SC4
13 0 U SD4

*END*
*REMARK* SamacSys ECAD Model
20007866/172412/2.50/24/3/Integrated Circuit
